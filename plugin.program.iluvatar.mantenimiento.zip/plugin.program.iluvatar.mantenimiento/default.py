# -*- coding: utf-8 -*-
import xbmcgui, xbmc, os, runpy
from xbmcvfs import translatePath

# Rutas
USERDATA = translatePath("special://userdata/")
SERVICE_PATH = os.path.join(os.path.dirname(__file__), "service.py")

def limpiar_cache():
    try:
        runpy.run_path(SERVICE_PATH, run_name="__main__")
        xbmcgui.Dialog().notification("Iluvatar", "Archivos temporales limpiados", xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        xbmcgui.Dialog().ok("Iluvatar", "Error al limpiar caché", str(e))

def configurar_buffer():
    opciones = [
        "Dispositivos de 1GB de RAM → 96 MB de caché",
        "Dispositivos de 2GB de RAM → 192 MB de caché",
        "Dispositivos de 4GB o más → 384 MB de caché"
    ]
    eleccion = xbmcgui.Dialog().select("Configurar Buffer", opciones)
    if eleccion == -1:
        return
    tamanos = [96, 192, 384]
    buffer_mb = tamanos[eleccion]
    try:
        import service
        service.write_advancedsettings(buffer_mb * 1024 * 1024)
        xbmcgui.Dialog().notification("Iluvatar", f"Buffer configurado a {buffer_mb} MB", xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        xbmcgui.Dialog().ok("Iluvatar", "Error configurando buffer", str(e))

def main_menu():
    opciones = [
        "Limpiar archivos temporales de Kodi",
        "Configurar Buffer",
        "Salir"
    ]
    while True:
        eleccion = xbmcgui.Dialog().select("Iluvatar Mantenimiento", opciones)
        if eleccion == 0:
            limpiar_cache()
        elif eleccion == 1:
            configurar_buffer()
        else:
            break

if __name__ == "__main__":
    main_menu()
