# -*- coding: utf-8 -*-
import xbmc, os, shutil
from xbmcvfs import translatePath

USERDATA = translatePath("special://userdata/")
ADV_PATH = os.path.join(USERDATA, "advancedsettings.xml")
ADV_BAK = os.path.join(USERDATA, "advancedsettings.xml.bak")

CACHE_PATHS = [
    translatePath("special://home/cache/"),
    translatePath("special://temp/"),
]

def clear_cache():
    for path in CACHE_PATHS:
        try:
            if os.path.exists(path):
                for root, dirs, files in os.walk(path):
                    for name in files:
                        try:
                            os.remove(os.path.join(root, name))
                        except:
                            pass
                    for name in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, name), ignore_errors=True)
                        except:
                            pass
        except:
            pass

def backup_advancedsettings():
    try:
        if os.path.exists(ADV_PATH):
            shutil.copy2(ADV_PATH, ADV_BAK)
    except:
        pass

def write_advancedsettings(buffer_bytes):
    try:
        content = f"""<?xml version="1.0" encoding="utf-8"?>
<advancedsettings>
  <cache>
    <memorysize>{int(buffer_bytes)}</memorysize>
    <readbufferfactor>20</readbufferfactor>
  </cache>
</advancedsettings>
"""
        backup_advancedsettings()
        with open(ADV_PATH, "w", encoding="utf-8") as f:
            f.write(content)
    except:
        pass

def run():
    clear_cache()

if __name__ == "__main__":
    run()
