Iluvatar Mantenimiento - v2.0.0
----------------------------------
Funciones:
- Limpieza automática de caché al iniciar Kodi.
- Perfiles de buffer: Bajo, Medio, Alto, Automático.
- Traducciones ES/EN.
- Copia de seguridad y restauración de advancedsettings.xml.
